class DistanceTime {
  final double price;
  final double distance;
  final double time;

  DistanceTime({required this.price, required this.distance, required this.time});

}
